$(document).ready(function () {
  autocomplete();
  hide_show();
  $('.slider').bxSlider({
    mode: 'horizontal',
    captions: false,
    slideWidth: 900,
    controls:true
  });
  advanced_option();
  validation();
});
function autocomplete(){
  $("#speciality-name").change(function(){ 
    var siteUrl = $('#siteurl').val();
    var Url = 'home/getBrand';
    var speciality_val = $("#speciality-name").val();
        $.ajax({
          url: Url,
          dataType: "json",
          data: {speciality: speciality_val},
          beforeSend: function(){ 
           $("#brand-name").empty(); 
           $("#brand-name option").remove();
           }
         }).done(function( data ) {
            $.map( data, function( item ) {
               $('#brand-name').append('<option value="'+item.id+'">' + item.value + '</option>');
          });
          $("#brand-name").trigger("chosen:updated");
          $("#brand-name").trigger("liszt:updated");
        });
  });
}
function hide_show(){
  $('#advanced_brand').hide();
  $('#advanced_option').click(function(){
    $("#advanced_brand").show();
  })
}

function advanced_option(){
  $('#speciality-name').change(function(e){
    if(($(this).val()) != ''){
      $('.advanced_div').fadeIn('slow');
      autocomplete();
    }else{
      $('.advanced_div').hide();
    }
  });
}

function validation(){
  $("#addbrandForm").validate({
      rules: {
        name: {
          required: true,
          minlength: 2
        },
        position: {
          required: true,
          number: true
        },
        image: {
          required: true,
          minlength: 5
        },
        speciality_id: {
          required: true
        }
      },
      messages: {
        name: {
          required: "Please enter a brand name",
          minlength: "Your username must consist of at least 2 characters"
        },
        position: {
          required: "Please provide a position"
        },
        image: {
          required: "Please provide a valid image"
        },
        speciality_id: "Please select a speciality"
      }
    });
}